import { Component } from '@angular/core';
import { NavController } from '@ionic/angular';
import { ToastController } from '@ionic/angular';
import { AlertController } from '@ionic/angular';
import { GroceriesServiceService } from '../groceries-service.service';
import { InputDialogServiceService } from '../input-dialog-service.service';


@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {

  title="Groceries";

 
  constructor(public navCtrl: NavController, public toastController: ToastController, public alertController: AlertController, public dataService: GroceriesServiceService, public inputDialogService: InputDialogServiceService) {}

    loadItems () {
      return this.dataService.getItems ();
    }
    
    async removeItem(item, index) {
      console.log("Removing item", item, index)
      const toast = await this.toastController.create({
        message: 'Removing Item - '+index+'...',
        duration: 2000
      });
      await toast.present();

      this.dataService.removeItem(index);
      
    }

    async editItem(item, index) {
      console.log("Editing item", item, index)
      const toast = await this.toastController.create({
        message: 'Editing Item - '+index+'...',
        duration: 2000
      });
      await toast.present();
      this.inputDialogService.showPrompt (item, index);
    }
    

    async addItem(item, index) {
      console.log("Adding Item");
      const toast = await this.toastController.create({
        message: 'Adding Item...',
        duration: 2000
      });
      await toast.present();
      this.inputDialogService.showPrompt ();
    }

}
